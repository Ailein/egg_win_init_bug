'use strict';

module.exports = appInfo => {
  const config = {};

  // should change to your own
  config.keys = appInfo.name + '_1498790496161_8240';

  // add your config here

  return config;
};
