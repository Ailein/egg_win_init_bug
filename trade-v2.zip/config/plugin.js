'use strict';

// had enabled by egg
// exports.static = true;
